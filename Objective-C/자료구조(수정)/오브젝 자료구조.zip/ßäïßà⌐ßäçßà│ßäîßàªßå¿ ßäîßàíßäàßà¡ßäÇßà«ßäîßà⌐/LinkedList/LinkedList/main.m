//
//  main.m
//  LinkedList
//
//  Created by MSW on 2015. 3. 18..
//  Copyright (c) 2015년 MSW. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "node.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        node *nodetest=[[node alloc]initWith:(NSInteger  *)2];
        [nodetest addNode:(NSInteger *)5];
        [nodetest addNode:(NSInteger *)6];
        [nodetest addNode:(NSInteger *)7];
        
        //NSLog(@"%zd",buf.num);
        //NSLog(@"%zd",buf.next.num);
        
        //리스트의 내용을 출력하는 부분
        node *buf=nodetest;
        while(buf.next!=nil){
            NSLog(@"%zd",buf.num);
            buf=buf.next;
        }
        NSLog(@"%zd",buf.num);
        //내용 출력
    }
    return 0;
}
