//
//  node.m
//  LinkedList
//
//  Created by MSW on 2015. 3. 18..
//  Copyright (c) 2015년 MSW. All rights reserved.
//

#import "node.h"

@implementation node
-(id)initWith: (NSInteger *)num
{
    self = [super init];
    if(self)
    {
        self.num = num;
    }
    self.pre=nil;
    self.next=nil;
    return self;
    
}

-(void)addNode:(NSInteger *)num{

    node *bufNode=self;
    while(bufNode.next!=nil){
        bufNode=bufNode.next;
    }
    bufNode.next=[[node alloc]initWith:num];//만들어서 연결
    bufNode.next.pre=bufNode;//헤더 연결

    
}
@end