//
//  node.m
//  queue
//
//  Created by MSW on 2015. 3. 12..
//  Copyright (c) 2015년 MSW. All rights reserved.
//

#import "node.h"

@implementation node

-(id)initWith: (NSInteger *)num
{
    self = [super init];
    if (self) {
        self.num = num;
        
    }
    return self;
}

@end
