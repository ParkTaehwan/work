//
//  main.m
//  queue
//
//  Created by MSW on 2015. 3. 12..
//  Copyright (c) 2015년 MSW. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "queue.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        
        queue *newQueue = [[queue alloc]init];
        [newQueue enqueue:(NSInteger *)1];
        [newQueue enqueue:(NSInteger *)5];
        
        [newQueue enqueue:(NSInteger *)20];
        
        [newQueue enqueue:(NSInteger *)15];
        
        [newQueue enqueue:(NSInteger *)4];
        
        [newQueue enqueue:(NSInteger *)6];
        
        
        for(int i=0; i<=5; i++){
        
        NSInteger *firstvalue = [newQueue dequeue];
        NSLog(@"%zd", firstvalue);
        }
        
    }
    return 0;
}
