//
//  main.m
//  stack
//
//  Created by MSW on 2015. 3. 12..
//  Copyright (c) 2015년 MSW. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "stack.h"
#import "node.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        
        stack *newStack = [[stack alloc]init];
        [newStack push:(NSInteger *)5];
        [newStack push:(NSInteger *)10];
        [newStack push:(NSInteger *)15];
        [newStack push:(NSInteger *)16];
        [newStack push:(NSInteger *)19];
        
        for ( int i=0; i <=4; i++) {
            NSInteger *returnValue = [newStack pop];
            NSLog(@"%zd", returnValue);
        }
        
    }
     return 0;
}
