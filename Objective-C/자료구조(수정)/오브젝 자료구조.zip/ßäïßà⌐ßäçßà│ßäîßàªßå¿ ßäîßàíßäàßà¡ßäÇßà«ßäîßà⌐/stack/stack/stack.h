//
//  stack.h
//  stack
//
//  Created by MSW on 2015. 3. 12..
//  Copyright (c) 2015년 MSW. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface stack : NSObject

-(void)push: (NSInteger *) num;
-(NSInteger *)pop;

@end
