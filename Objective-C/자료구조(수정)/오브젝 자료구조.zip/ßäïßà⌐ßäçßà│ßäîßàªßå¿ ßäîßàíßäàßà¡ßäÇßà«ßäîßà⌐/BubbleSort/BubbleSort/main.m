//
//  main.m
//  BubbleSort
//
//  Created by MSW on 2015. 3. 12..
//  Copyright (c) 2015년 MSW. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSArray+Bsort.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSArray* sorted = [@[@6, @5, @3, @1, @8, @7, @2, @4] sortedArrayWithBubbleSort];
        NSLog(@"Sorted array is %@", sorted);
       
    }
    return 0;
}
