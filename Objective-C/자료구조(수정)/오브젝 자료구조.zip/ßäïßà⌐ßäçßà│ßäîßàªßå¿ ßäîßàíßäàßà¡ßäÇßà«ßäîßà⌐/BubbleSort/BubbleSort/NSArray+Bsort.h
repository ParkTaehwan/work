//
//  NSArray+Bsort.h
//  BubbleSort
//
//  Created by MSW on 2015. 3. 12..
//  Copyright (c) 2015년 MSW. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray(Bsort)
-(NSArray*)sortedArrayWithBubbleSort;
@end
